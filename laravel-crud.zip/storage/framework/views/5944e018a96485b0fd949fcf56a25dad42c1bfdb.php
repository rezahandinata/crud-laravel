<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                    
                   <div class="card text-center">
                      <div class="card-header">
                        <h4 class="float-left">Tambah Category</h4>
                      </div>
                      <div class="card-body">
                        <form action="<?php echo e(url('/category/store')); ?>" method="POST">

                           <?php echo e(csrf_field()); ?>

                            <div class="form-group row">
                                <label for="jenis_category" class="col-sm-2 col-form-label">Jenis Category</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="jenis_category" name="jenis_category" placeholder="Jenis" required="">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="nama_category" class="col-sm-2 col-form-label">Nama Category</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="nama_category" name="nama_category"  placeholder="Nama" required="">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 form-control-label text-right"></label>
                                <div class="col-sm-10">
                                    <button class="btn btn-inline btn-success mt-10">Simpan</button>
                                </div>
                            </div>
                    
                        </form>
                      </div>
    
                    </div>

                </div>
            
        </div>
    </div>
           
<?php $__env->stopSection(); ?>

<?php $__env->startSection("css"); ?>
    <link rel="stylesheet" href="<?php echo e(url('template')); ?>/css/datatable/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("javascript"); ?>
    <script src="<?php echo e(url('template')); ?>/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo e(url('template')); ?>/js/datatable/jquery.dataTables.min.js"></script>

    <script>
       $(document).ready(function() {
            $('#example').DataTable();
        } );
    </script>

    <script src="<?php echo e(url('template')); ?>/js/app.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-crud\resources\views/category/tambah.blade.php ENDPATH**/ ?>