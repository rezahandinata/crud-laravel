<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                    
                   <div class="card text-center">
                      <div class="card-header">
                        <h4 class="float-left">Products</h4>
                        <div class="float-right">
                            <a class="btn btn-info" href="<?php echo e(url('products/tambah')); ?>"><i class="fas fa-plus"></i> Tambah</a></div>
                      </div>
                      <div class="card-body">
                        <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Nama Products</th>
                                <th>Nama Category</th>
                                <th>harga</th>
                                <th>Deskripsi</th>
                                <th>Berat</th>
                                <th>Foto</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                            <tbody>
                                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($prd->id_products); ?></td>
                                    <td><?php echo e($prd->nama_products); ?></td>
                                    <td></td>
                                    <td><?php echo e($prd->harga); ?></td>
                                    <td><?php echo e($prd->deskripsi); ?></td>
                                    <td><?php echo e($prd->berat); ?></td>
                                    <td><?php echo e($prd->gambar); ?></td>
                                    <td>
                                        <a class="btn btn-warning" href="<?php echo e(url('products/edit/'.encrypt($prd->id_products))); ?>"><i class="fas fa-edit"></i> Edit</a>
                                        <a class="btn btn-danger" href=""><i class="fas fa-times"></i> Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                         </table>
                      </div>
    
                    </div>

                </div>
            
        </div>
    </div>
           
<?php $__env->stopSection(); ?>

<?php $__env->startSection("css"); ?>
    <link rel="stylesheet" href="<?php echo e(url('template')); ?>/css/datatable/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("javascript"); ?>
    <script src="<?php echo e(url('template')); ?>/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo e(url('template')); ?>/js/datatable/jquery.dataTables.min.js"></script>

    <script>
       $(document).ready(function() {
            $('#example').DataTable();
        } );
    </script>

    <script src="<?php echo e(url('template')); ?>/js/app.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-crud\resources\views/products/index.blade.php ENDPATH**/ ?>