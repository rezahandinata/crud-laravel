<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                    
                   <div class="card text-center">
                      <div class="card-header">
                        <h4 class="float-left">Tambah Category</h4>
                      </div>
                      <div class="card-body">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(url('/category/update', $cat->id_category)); ?>" method="POST">

                           <?php echo e(csrf_field()); ?>

                           <input type="hidden" name="id" value="<?php echo e($cat->id_category); ?>">
                            <div class="form-group row">

                                <label for="jenis_category" class="col-sm-2 col-form-label">Jenis Category</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="jenis_category" name="jenis_category" placeholder="Jenis" value="<?php echo e($cat->jenis_category); ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="nama_category" class="col-sm-2 col-form-label">Nama Category</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="nama_category" name="nama_category"  placeholder="Nama" value="<?php echo e($cat->nama_category); ?>">
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group row">
                                <label class="col-sm-2 form-control-label text-right"></label>
                                <div class="col-sm-10">
                                    <button class="btn btn-inline btn-success mt-10">Simpan</button>
                                </div>
                            </div>
                    
                        </form>
                      </div>
    
                    </div>

                </div>
            
        </div>
    </div>
           
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-crud\resources\views/category/edit.blade.php ENDPATH**/ ?>